int i,j
float m,n;
float fun(int x,char y)
{
    int a[10],b[10][20];
    i+j=b[3,5];
    i=#+1;
    j=0789;
    m=0xAB;
    return 1;
}