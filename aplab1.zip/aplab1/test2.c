int a[5];
float b;
char c[6]; 
int func(int i,int y){
    return i;
}
int func(){
    return 0;  
}
int main(){
    //this is a test
    int i;
    char p[10];
    float d = 5.5 , i;  
    j = i + 1;  
    inc(i);    

    a[i] = 2.2;    
   
    10 = i;         
    i ++;

    a = a+1;       
    d +=10 ;      
    
    func();
    func(1);      
    func(2 , 3);      
    func(2 , 3.1);    
    func(1 , 2 , 3.1);  

    i[10];          
    i(10);          

    p[1.5] = 10;    
    p[2] = 'A';

    return d;      
}

