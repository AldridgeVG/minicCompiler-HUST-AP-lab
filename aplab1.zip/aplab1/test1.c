int cjt1,cjt2;
float cjt3,cjt4;
char cjt5;
/*111111*/
/*2222
2222*/
int test(int a)
{
  int a1,a2=1;
  a1=1.1;
  a1=a1/a2;
  if(a1==1)
  {
    a2=3;
    break;
  }//?????????
  {
    int j;
    j=a2;
    a2++;
  }
  return 1.2;
}
int main()
{
  int a1,a2=1;
  int a3[30];
  test();
  test(3);
  for(a1=0,int a5=0;a5<3;a5++,a1++)
  {
    int i=a1;
    a1=3;
    break;
  }
  return 1;
}
